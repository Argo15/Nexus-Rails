#ifndef MUSIC_PLAYER_H
#define MUSIC_PLAYER_H
using namespace std;

class MusicPlayer
{
public:
	int init();
	void jumpSound();
	void hurtSound();
	void setSpeed(float);
private:
};

#endif